  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2020
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the "Windowed Mode" folder to the "modloader" folder of your GTA SA, or VC, or III. Or to the game folder, or "scripts."
The .exe file is optional to use the CoordsManager menu, to copy and paste coordinates during windowed mode.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html



ALT + Enter  � Toggle window mode
Ctrl-Enter   � Toggle the border
Shift-Enter  � Toggle the menu
Ctrl-Alt     � Toggle the cursor
With borders, you can resize the window with the mouse while the game is paused.
 


Version: v1.6
--------------------

Author: ThirteenAG


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

