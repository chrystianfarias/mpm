
//Open ini
let ini = openIni("modloader/widescreen_fix/Widescreen Fix by ThirteenAG/GTASA.WidescreenFix.ini");

//Define resolution list
let resolutionListOptions = [
    { x:"0", y:"0", name:"Use game resolution"},
    { x:"720", y:"480", name:"480p (720x480)" },
    { x:"1280", y:"720", name:"720p (1280x720)" },
    { x:"1920", y:"1080", name:"1080p (1920x1080)"},
    { x:"3840", y:"2160", name:"4K UHD (3840x2160)" }
];
//Create dialog
dialog = createDialog();
dialog.setSize(200,200);

dialog.createLabel("Use this option to override the game resolution");
//Create resolutions string list
let resStrings = resolutionListOptions.map(function(res){ return res.name });
//Resolution list UI
let resolutionList = dialog.createList(resStrings);
//Set event
resolutionList.setOnSelect(onListChange);

function onListChange(index)
{
    let main = ini.getSection("MAIN");
    let res = resolutionListOptions[index];
    main.setValue("ResX", res.x);
    main.setValue("ResY", res.y);
}

//Open dialog
if (dialog.show() == "OK")
{
    ini.save();
    message("INI Saved", "Windowned Mod", "info");
}
